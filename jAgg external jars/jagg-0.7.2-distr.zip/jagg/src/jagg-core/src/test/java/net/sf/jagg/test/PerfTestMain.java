package net.sf.jagg.test;

/**
 * Just to run PerformanceTest in the command line.
 */
public class PerfTestMain
{
   public static void main(String[] args)
   {
      new PerformanceTest().testPerf1();
   }
}
